MY DAILY MOTIVE — V2

This version is inspired by the paper habit-sheet style shown in the supplied screenshots, but redesigned for a phone.

MAIN FEATURES
- Today screen: one-tap checkboxes, daily score, streak, total wins.
- 30-Day Sheet: a spreadsheet-style 30-day grid. Tap any box to mark/unmark a habit for that date.
- Growth: 14-day bar chart, consistency percentage, habit-by-habit completion, current streaks, and simple improvement advice.
- Add/edit-ready habit structure.
- Default routines include wake-up, no snooze, water, exercise, stretching, NEBOSH study, breathing/meditation, social-media limit, no alcohol, sleep routine.
- Offline-first: localStorage + service worker. No account, server, API, ads or paid services.

ANDROID INSTALL
1. Extract the ZIP.
2. Host the folder on a free static host (GitHub Pages is one option) or use any local/static web server.
3. Open the site in Chrome on Android.
4. Chrome menu -> Add to Home screen / Install app.

NOTE
A browser PWA is intentionally used here because it is free and easy to update. It is not an APK yet.
